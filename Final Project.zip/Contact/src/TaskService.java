import java.util.ArrayList;
import java.util.Scanner;

public class TaskService {
	
	
		public String ID = "";
		public String name = "";
		public String description = "";
		Integer length;

		//add to an array of objects for the contacts class
		public void add(ArrayList<Task> task) {
			Scanner sc = new Scanner(System.in);
			length = task.size();
			
			while (ID.length() == 0) {
				ID = length.toString();
		    	System.out.println("ID is: " + ID);
			}
			while (name.length() == 0 || name.length() > 20) {
	    		System.out.println("Enter First Name: ");
	    		name = sc.nextLine();
	    	}
			while (description.length() == 0 || description.length() > 50) {
				System.out.println("Enter Description: ");
				description = sc.nextLine();
			}
			
			Task add = new Task(ID, name, description);
				
			//added add object to array list contact
			task.add(add);
			
		}
		
		public void delete(ArrayList<Task> al, int index) {
			//check for functionality this might not work
			//contact.remove(contact.indexOf(contactName));
			al.remove(index);
			System.out.println("Task Deleted");
			}
		public void update(ArrayList<Task> al, int index) {
			//integer index = contact.indexOf(contactName);
			System.out.println("Task Update");
			Task tk;
			Scanner sc = new Scanner(System.in);
			tk = al.get(index);
			
			//resets all of the values except ID which is permanent
			tk.setName("");
			tk.setDescription("");
			
			
	    	while (tk.getName().length() == 0 || tk.getName().length() > 20) {
	    		System.out.println("Enter Name: ");
	    		name = sc.nextLine();
	    		tk.setName(name);
	    	}
			while (tk.getDescription().length() == 0 || tk.getDescription().length() > 50) {
				System.out.println("Enter Description: ");
				description = sc.nextLine();
				tk.setDescription(description);
			}
		
	}


}
