
public class Task {
		private String ID = "";
		private String name = "";
		private String description = "";
		
		
		
		public Task(String ID, String name, String description) {
			//check whether the value sent to constructor is valid or not if it isnt valid it throws a IllegalArgumentException
			
			if(ID == null || ID.length()>10) {
				throw new IllegalArgumentException("Invalid ID");
			}
			if(name == null || name.length()>20) {
				throw new IllegalArgumentException("Invalid name");
			}
			if(description == null || description.length()>50) {
				throw new IllegalArgumentException("Invalid description");
			}
			//if not exception is thrown the values are set
			setId(ID);
			setName(name);
			setDescription(description);
		}
		//setters
		//setter for id
		public void setId(String ID) {
				this.ID = ID;
		}
		//setter for first name
		public void setName(String name) {
				this.name = name;
		}
		//setter for last name
		public void setDescription(String description) {
			
				this.description = description;
		}
		
		//getters
		public String getId() {
			return ID;
		}
		public String getName() {
		    return name;
		}
		public String getDescription() {
		    return description;
		}
}
