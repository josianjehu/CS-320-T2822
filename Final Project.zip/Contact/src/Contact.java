public class Contact{
	private String ID = "";
	private String firstName = "";
	private String lastName = "";
	private String phone = "";
	private String address = "";
	
	//need to add message to reenter string if set fails
	
	
	
	public Contact(String ID, String firstName, String lastName, String phone, String address) {
		//check whether the value sent to constructor is valid or not if it isnt valid it throws a IllegalArgumentException
		if(firstName == null || firstName.length()>10) {
			throw new IllegalArgumentException("Invalid first name");
		}
		if(ID == null || ID.length()>10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		if(lastName == null || lastName.length()>10) {
			throw new IllegalArgumentException("Invalid name");
		}
		if(phone == null || phone.length()>10 || phone.length()<10) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		if(address == null || address.length()>10) {
			throw new IllegalArgumentException("Invalid address");
		}
		//if not exception is thrown the values are set
		setId(ID);
		setFirstName(firstName);
		setLastName(lastName);
		setPhone(phone);
		setAddress(address);
	}
	//setters
	//setter for id
	public void setId(String ID) {
			this.ID = ID;
	}
	//setter for first name
	public void setFirstName(String firstName) {
			this.firstName = firstName;
	}
	//setter for last name
	public void setLastName(String lastName) {
		
			this.lastName = lastName;
	}
	//setter for phone
	public void setPhone(String phone) {
			this.phone = phone;
	}
	public void setAddress(String address) {
			this.address = address;
	}
	
	//getters
	public String getId() {
		return ID;
	}
	public String getFirstName() {
	    return firstName;
	}
	public String getLastName() {
	    return lastName;
	}
	public String getPhone() {
	    return phone;
	}
	public String getAddress() {
	    return address;
	}
	
}