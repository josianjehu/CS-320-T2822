import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentTest {
	Calendar currDate = Calendar.getInstance();
	
	@Test
	void testAppointmentClass() {
		currDate.set(2024, 02, 01);
		Appointment appointment = new Appointment("1", currDate, "This is a task.");
		assertTrue(appointment.getId().equals("1"));
		assertTrue(appointment.getDate().equals(currDate));
		assertTrue(appointment.getDescription().equals("This is a task."));
	}
	//checks if when id is too long IllegalArgumentException is thrown
	@Test
	void testAppointmentClassIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Appointment("12345678901", currDate, "Domenech");
		});
	}
	//checks if when id is null IllegalArgumentException is thrown
	@Test
	void testAppointmentClassIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Appointment(null, currDate, "Domenech");
		});
	}
	//checks if when first name is too long IllegalArgumentException is thrown
	@Test
	void testAppointmentClassDateBefore() {
		currDate.set(2021, 02, 01);
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Appointment("1", currDate, "Domenech");
		});
	}
	//checks if when first name is null IllegalArgumentException is thrown
	@Test
	void testAppointmentClassDateNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Task("1", null, "Domenech");
		});
	}
	//checks if when last name is too long IllegalArgumentException is thrown
	@Test
	void testAppointmentClassDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			currDate.set(2024, 02, 01);
			new Appointment("1", currDate, "123456789012345678901234567890123456789012345678901234567890");
		});
	}
	//checks if when last name is null IllegalArgumentException is thrown
	@Test
	void testAppointmentClassDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Appointment("1", currDate, null);
		});
	}

}
