import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskTest {

	@Test
	void testTaskClass() {
		Task task = new Task("1", "Task", "This is a task.");
		assertTrue(task.getId().equals("1"));
		assertTrue(task.getName().equals("Task"));
		assertTrue(task.getDescription().equals("This is a task."));
	}
	//checks if when id is too long IllegalArgumentException is thrown
	@Test
	void testTaskClassIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Task("12345678901", "Jehu Domenech", "Domenech");
		});
	}
	//checks if when id is null IllegalArgumentException is thrown
	@Test
	void testTaskClassIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Task(null, "Jehu Domenech", "Domenech");
		});
	}
	//checks if when first name is too long IllegalArgumentException is thrown
	@Test
	void testTaskClassNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Task("1", "Jehu Domenech 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0", "Domenech");
		});
	}
	//checks if when first name is null IllegalArgumentException is thrown
	@Test
	void testTaskClassNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Task("1", null, "Domenech");
		});
	}
	//checks if when last name is too long IllegalArgumentException is thrown
	@Test
	void testTaskClassDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Task("1", "Jehu", "123456789012345678901234567890123456789012345678901234567890");
		});
	}
	//checks if when last name is null IllegalArgumentException is thrown
	@Test
	void testTaskClassDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Task("1", "Jehu", null);
		});
	}

}
