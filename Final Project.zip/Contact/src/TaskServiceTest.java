import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import org.junit.jupiter.api.Test;

class TaskServiceTest {
	TaskService ts = new TaskService();
	ArrayList<Task> al = new ArrayList<Task>();

		//tests add function and checks whether the array list has an object
		@Test
		void testTaskServiceClassFunctionAdd() {
			ts.add(al);
			assertTrue(Integer.valueOf(al.size()).equals(1));
	}
		//tests delete function by first running the add functions saving the values and when entering different
		//values for each field it checks whether they are different
		@Test
		void testTaskServiceClassFunctionUpdate() {
			ts.add(al);
			String name = al.get(0).getName();
			String description = al.get(0).getDescription();
			ts.update(al, 0);
			assertTrue(!al.get(0).getName().equals(name));
			assertTrue(!al.get(0).getDescription().equals(description));
	}
		//tests delete function by first running add function and then deleting by checking whether the array list is empty
		@Test
		void testTaskServiceClassFunctionDelete() {
			ts.add(al);
			assertTrue(Integer.valueOf(al.size()).equals(1));
			ts.delete(al, 0);
			assertTrue(Integer.valueOf(al.size()).equals(0));
	}


}
