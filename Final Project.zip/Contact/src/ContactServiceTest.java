

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class ContactServiceTest {
	ContactService cs = new ContactService();
	ArrayList<Contact> al = new ArrayList<Contact>();

		//tests add function and checks whether the array list has an object
		@Test
		void testContactServiceClassFunctionAdd() {
			cs.add(al);
			assertTrue(Integer.valueOf(al.size()).equals(1));
	}
		//tests delete function by first running the add functions saving the values and when entering different
		//values for each field it checks whether they are different
		@Test
		void testContactServiceClassFunctionUpdate() {
			cs.add(al);
			String firstName = al.get(0).getFirstName();
			String lastName = al.get(0).getLastName();
			String phone = al.get(0).getPhone();
			String address = al.get(0).getAddress();
			cs.update(al, 0);
			assertTrue(!al.get(0).getFirstName().equals(firstName));
			assertTrue(!al.get(0).getLastName().equals(lastName));
			assertTrue(!al.get(0).getPhone().equals(phone));
			assertTrue(!al.get(0).getAddress().equals(address));
	}
		//tests delete function by first running add function and then deleting by checking whether the array list is empty
		@Test
		void testContactServiceClassFunctionDelete() {
			cs.add(al);
			assertTrue(Integer.valueOf(al.size()).equals(1));
			cs.delete(al, 0);
			assertTrue(Integer.valueOf(al.size()).equals(0));
	}
		

}
