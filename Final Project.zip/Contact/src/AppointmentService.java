import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class AppointmentService {
	
	
	public String ID = "";
	public Calendar date = Calendar.getInstance();
	public String description = "";
	public String month = "";
	public String day = "";
	public String year = "";
	Integer length;

	//add to an array of objects for the contacts class
	public void add(ArrayList<Appointment> appointment) {
		Scanner sc = new Scanner(System.in);
		length = appointment.size();
		
		while (ID.length() == 0) {
			ID = length.toString();
	    	System.out.println("ID is: " + ID);
		}
		while (year.length() == 0 || month.length() == 0 || day.length() == 0) {
			System.out.println("Enter Month (mm-dd-yyyy): ");
    		month = sc.nextLine();
    		System.out.println("Enter Date (mm-dd-yyyy): ");
    		day = sc.nextLine();
    		System.out.println("Enter Year (mm-dd-yyyy): ");
    		year = sc.nextLine();
    		date.set(Integer.parseInt(year), Integer.parseInt(month), Integer.parseInt(day));
    		
    	}
		while (description.length() == 0 || description.length() > 50) {
			System.out.println("Enter Description: ");
			description = sc.nextLine();
		}
		
		Appointment add = new Appointment(ID, date, description);
			
		//added add object to array list contact
		appointment.add(add);
		
	}
	
	public void delete(ArrayList<Appointment> al, int index) {
		//check for functionality this might not work
		//contact.remove(contact.indexOf(contactName));
		al.remove(index);
		System.out.println("Appointment Deleted");
		}
}
