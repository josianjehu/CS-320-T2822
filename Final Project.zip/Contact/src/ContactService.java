import java.util.ArrayList;
import java.util.Scanner;

public class ContactService {
	public String ID = "";
	public String firstName = "";
	public String lastName = "";
	public String phone = "";
	public String address = "";
	public Integer length;

	//add to an array of objects for the contacts class
	public void add(ArrayList<Contact> contact) {
		Scanner sc = new Scanner(System.in);
		length = contact.size();
		
		while (ID.length() == 0) {
			ID = length.toString();
	    	System.out.println("ID is: " + ID);
		}
		while (firstName.length() == 0 || firstName.length() > 10) {
    		System.out.println("Enter First Name: ");
    		firstName = sc.nextLine();
    	}
		while (lastName.length() == 0 || lastName.length() > 10) {
			System.out.println("Enter Last Name: ");
			lastName = sc.nextLine();
		}
		while (phone.length() != 10) {
			System.out.println("Enter Phone Number: ");
			phone = sc.nextLine();
		}
		while (address.length() == 0 || address.length() > 30) {
			System.out.println("Enter Address: ");
			address = sc.nextLine();
		}
		
		Contact add = new Contact(ID, firstName, lastName, phone, address);
			
		//added add object to array list contact
		contact.add(add);
		
	}
	
	public void delete(ArrayList<Contact> al, int index) {
		//check for functionality this might not work
		//contact.remove(contact.indexOf(contactName));
		al.remove(index);
		System.out.println("Contact Deleted");
		}
	public void update(ArrayList<Contact> al, int index) {
		//int index = contact.indexOf(contactName);
		System.out.println("Contact Update");
		Contact cs;
		Scanner sc = new Scanner(System.in);
		cs = al.get(index);
		
		//resets all of the values except ID which is permanent
		cs.setFirstName("");
		cs.setLastName("");
		cs.setPhone("");
		cs.setAddress("");
		
		
    	while (cs.getFirstName().length() == 0 || cs.getFirstName().length() > 10) {
    		System.out.println("Enter First Name: ");
    		firstName = sc.nextLine();
    		cs.setFirstName(firstName);
    	}
		while (cs.getLastName().length() == 0 || cs.getLastName().length() > 10) {
			System.out.println("Enter Last Name: ");
			lastName = sc.nextLine();
			cs.setLastName(lastName);
		}
		while (cs.getPhone().length() != 10) {
			System.out.println("Enter Phone Number: ");
			phone = sc.nextLine();
			cs.setPhone(phone);
		}
		while (cs.getAddress().length() == 0 || cs.getAddress().length() > 30) {
			System.out.println("Enter Address: ");
			address = sc.nextLine();
			cs.setAddress(address);
		}
		}
	
}
