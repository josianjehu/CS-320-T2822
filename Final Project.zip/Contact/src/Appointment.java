import java.util.Calendar;
import java.util.Date;
public class Appointment {

		private String ID = "";
		private Calendar date; //check date
		private String description = "";
		long millis=System.currentTimeMillis();  
		
		
		public Appointment(String ID, Calendar date, String description) {
			//check whether the value sent to constructor is valid or not if it isnt valid it throws a IllegalArgumentException
			Calendar currDate = Calendar.getInstance();
			
			if(ID == null || ID.length()>10) {
				throw new IllegalArgumentException("Invalid ID");
			}
			//modify
			if(date == null || currDate.after(date)) {
				throw new IllegalArgumentException("Invalid date");
			}
			if(description == null || description.length()>50) {
				throw new IllegalArgumentException("Invalid description");
			}
			//if not exception is thrown the values are set
			setId(ID);
			setDate(date);
			setDescription(description);
		}
		//setters
		//setter for id
		public void setId(String ID) {
				this.ID = ID;
		}
		//setter for first name
		//modify
		public void setDate(Calendar date) {
				this.date = date;
		}
		//setter for last name
		public void setDescription(String description) {
			
				this.description = description;
		}
		
		//getters
		public String getId() {
			return ID;
		}
		public Calendar getDate() {
		    return date;
		}
		public String getDescription() {
		    return description;
		}

}
