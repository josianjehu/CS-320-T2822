import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

	AppointmentService as = new AppointmentService();
	ArrayList<Appointment> al = new ArrayList<Appointment>();

		//tests add function and checks whether the array list has an object
		@Test
		void testTaskServiceClassFunctionAdd() {
			as.add(al);
			assertTrue(Integer.valueOf(al.size()).equals(1));
	}
		
		//tests delete function by first running add function and then deleting by checking whether the array list is empty
		@Test
		void testTaskServiceClassFunctionDelete() {
			as.add(al);
			assertTrue(Integer.valueOf(al.size()).equals(1));
			as.delete(al, 0);
			assertTrue(Integer.valueOf(al.size()).equals(0));
	}

}
