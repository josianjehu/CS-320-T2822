

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {

	//checks whether values are correctly set in the constructor when object is made
	@Test
	void testContactClass() {
		Contact contact = new Contact("1", "Jehu", "Domenech", "2105353226", "Po Box 576");
		assertTrue(contact.getId().equals("1"));
		assertTrue(contact.getFirstName().equals("Jehu"));
		assertTrue(contact.getLastName().equals("Domenech"));
		assertTrue(contact.getPhone().equals("2105353226"));
		assertTrue(contact.getAddress().equals("Po Box 576"));
	}
	//checks if when id is too long IllegalArgumentException is thrown
	@Test
	void testContactClassIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("1234567890123", "Jehu", "Domenech", "2105353226", "Po Box 576");
		});
	}
	//checks if when id is null IllegalArgumentException is thrown
	@Test
	void testContactClassIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact(null, "Jehu", "Domenech", "2105353226", "Po Box 576");
		});
	}
	//checks if when first name is too long IllegalArgumentException is thrown
	@Test
	void testContactClassFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("1", "Jehu Domenech Ortiz", "Domenech", "2105353226", "Po Box 576");
		});
	}
	//checks if when first name is null IllegalArgumentException is thrown
	@Test
	void testContactClassFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("1", null, "Domenech", "2105353226", "Po Box 576");
		});
	}
	//checks if when last name is too long IllegalArgumentException is thrown
	@Test
	void testContactClassLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("1", "Jehu", "Jehu Domenech Ortiz", "2105353226", "Po Box 576");
		});
	}
	//checks if when last name is null IllegalArgumentException is thrown
	@Test
	void testContactClassLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("1", "Jehu", null, "2105353226", "Po Box 576");
		});
	}
	//checks if when phone is too long IllegalArgumentException is thrown
	@Test
	void testContactClassPhoneTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("1", "Jehu", "Domenech", "210535322602105353226", "Po Box 576");
		});
	}
	//checks if when phone is too short IllegalArgumentException is thrown
	@Test
	void testContactClassPhoneTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("1", "Jehu", "Domenech", "2105353", "Po Box 576");
		});
	}
	//checks if when phone is null IllegalArgumentException is thrown
	@Test
	void testContactClassPhoneNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("1", "Jehu", "Domenech", null, "Po Box 576");
		});
	}
	//checks if when address is too long IllegalArgumentException is thrown
	@Test
	void testContactClassAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("1", "Jehu", "Domenech", "2105353226", "1234567890123456789012345678901");
		});
	}
	//checks if when address is null IllegalArgumentException is thrown
	@Test
	void testContactClassAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("1", "Jehu", "Domenech", "2105353226", null);
		});
	}

}
